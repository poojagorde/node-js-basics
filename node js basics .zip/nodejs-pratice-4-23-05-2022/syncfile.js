const fs  =require("fs");
const path=require("path");
console.log("PWD is "+process.cwd());    //to get present working directory

//File writing
const filepath=path.join(process.cwd(),"test.txt");       // adding path to test.txt
let filedata="Hi Yaswitha";               //data to be written
fs.writeFileSync(filepath,filedata);  //for writing data

//File Reading
console.log("File Reading started....");
const contents=fs.readFileSync(filepath,"utf-8");  
console.log("File contents : ",contents);
console.log("File Reading is done .....");

//File Renaming
fs.rename("test.txt","temp.txt",()=>console.log("File is renamed"));

//File Deletion
fs.unlink("test.txt",()=>console.log("File is removed"));

//File Update 
fs.appendFileSync('temp.txt',"i am appended ...");